// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
//
// import 'Home.dart';
//
//
// class login extends StatelessWidget {
//   login({super.key});
//   TextEditingController usercontroller = TextEditingController();
//
//   TextEditingController passcontroller= TextEditingController();
//
//
//   Future<void> loginAccount(String emailAddress,String password,var context) async {
//     try {
//       final credential = await FirebaseAuth.instance.signInWithEmailAndPassword(
//           email: emailAddress,
//           password: password
//       );
//       print(credential);
//       usercontroller.clear();
//       passcontroller.clear();
//       Navigator.push(context, MaterialPageRoute(builder: (context) {
//         return Home();
//       },));
//     } on FirebaseAuthException catch (e) {
//       if (e.code == 'user-not-found') {
//         print('No user found for that email.');
//       } else if (e.code == 'wrong-password') {
//         print('Wrong password provided for that user.');
//       }
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return SafeArea(
//       child: Scaffold(
//         body: Container(
//           decoration: BoxDecoration(
//             image: DecorationImage(
//               image: NetworkImage('https://images.unsplash.com/photo-1558591710-4b4a1ae0f04d?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTh8fHdoaXRlJTIwJTIwYmFja2dyb3VuZHxlbnwwfHwwfHx8MA%3D%3D',
//               ),
//               fit: BoxFit.cover,
//             ),
//           ),
//           padding: EdgeInsets.all(20.0),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.stretch,
//             children: [
//
//               SizedBox(height: 150),
//               Column(
//                 children: [
//                   // Text('SIGN UP'),
//                   Text(
//                     'LOGIN HERE',
//                     style: TextStyle(fontWeight:FontWeight.w600,
//                       fontSize: 20, // Set the desired font size
//                       color: Colors.blueGrey,
//                     ),
//                   ),
//                   SizedBox(height: 10),
//
//
//                 ],
//               ),
//               TextField(
//                 controller: usercontroller,
//                 decoration: InputDecoration(
//                   labelText: 'Enter your Username',
//                   border: OutlineInputBorder(),
//                 ),
//               ),
//               SizedBox(height: 20),
//               TextField(
//                 controller: passcontroller,
//                 decoration: InputDecoration(
//                   labelText: 'Enter your Password',
//                   border: OutlineInputBorder(),
//                 ),
//               ),
//               SizedBox(height: 20),
//               Row(
//                 children: [
//                   ElevatedButton(
//                     onPressed: () {
//                       loginAccount(usercontroller.text, passcontroller.text, context);
//                     },
//                     child: Text('Login'),
//                     style: ElevatedButton.styleFrom(
//                       backgroundColor: Colors.blueGrey,
//                       foregroundColor: Colors.white,
//                     ),
//                   ),
//
//                 ],
//
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'Home.dart';

class login extends StatelessWidget {
  login({Key? key});

  TextEditingController userController = TextEditingController();
  TextEditingController passController = TextEditingController();

  Future<void> loginAccount(
      String emailAddress, String password, BuildContext context) async {
    try {
      final credential = await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: emailAddress,
        password: password,
      );




      print(credential);
      userController.clear();
      passController.clear();
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => Home()),
      );
    } on FirebaseAuthException catch (e) {
      if (e.code == 'user-not-found') {
        print('No user found for that email.');
      } else if (e.code == 'wrong-password') {
        print('Wrong password provided for that user.');
      }
    }

  }
  setData(String text1,String text2)async{
    SharedPreferences pref = await SharedPreferences.getInstance();
    pref.setString('password', text1);
    pref.setString('userEmail', text2);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
              image: NetworkImage(
                'https://images.unsplash.com/photo-1558591710-4b4a1ae0f04d?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTh8fHdoaXRlJTIwJTIwYmFja2dyb3VuZHxlbnwwfHwwfHx8MA%3D%3D',
              ),
              fit: BoxFit.cover,
            ),
          ),
          padding: EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              SizedBox(height: 150),
              Column(
                children: [
                  Text(
                    'LOGIN HERE',
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 20,
                      color: Colors.blueGrey,
                    ),
                  ),
                  SizedBox(height: 10),
                ],
              ),
              TextField(
                controller: userController,
                decoration: InputDecoration(
                  labelText: 'Enter your Username',
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 20),
              TextField(
                controller: passController,
                decoration: InputDecoration(
                  labelText: 'Enter your Password',
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 20),
              Row(
                children: [

                  ElevatedButton(
                    onPressed: () async {
                      await loginAccount(
                        userController.text,
                        passController.text,
                        context,
                      );
                      setData(userController.text,passController.text);

                      // After login is successful, navigate to Home page and pass username and password
                      Navigator.push(context, MaterialPageRoute(
                        builder: (context) {
                          return Home();
                        },
                      ),

                      );
                    },
                    child: Text('Login'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blueGrey,
                      foregroundColor: Colors.white,
                    ),
                  ),


                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
